# 1 )Variable Swap: Write a Python program to swap the values of two variables without using a temporary variable.

# Initial values
a = 5
b = 10

# Swapping the values
a, b = b, a

# Output the results
print("After swapping:")
print("a =", a)
print("b =", b)
