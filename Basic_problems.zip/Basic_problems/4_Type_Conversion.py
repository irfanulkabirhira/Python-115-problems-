# Type Conversion: Given a list of integers, write a Python program to convert each element of the list to a string.

# List of integers
int_list = [1, 2, 3, 4, 5]

# Converting each element to a string
str_list = [str(i) for i in int_list]

# Output the results
print("List of strings:", str_list)
