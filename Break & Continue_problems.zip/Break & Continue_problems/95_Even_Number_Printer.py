# 93. Even Number Printer: Write a Python program to print all even numbers from 1 to 20. Use a for loop and continue to skip odd numbers.

